package appempresax;

import java.text.DecimalFormat;

public class Cargo {
    //Atributos
    private String cargo;
    private float salario;
    private int horasExtras;
    //Construtor iniciadno apenas o cargo, pois as Horas Extras e o salarios são usados e/ou iniciados apenas nessa classe
    public Cargo(String cargo) {
        this.cargo = cargo;
        salario(); // quando o construtor inicia ele automaticamente chama o metodo salario
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public float getSalario() {
        return salario;
    }

    public int getHorasExtras() {
        return horasExtras;
    }

    public void setHorasExtras(int horasExtras) {
        this.horasExtras = horasExtras;
    }

    //Método salário tem o objetivo de atribuir o valor do salario pré definido pelo sistema a partir do cargo escolhido 
    public String salario() {
        String resposta = "";
        if (cargo.equals("Aprendiz")) {
            salario = 800;
            resposta = "R$" + salario;
        } else if (cargo.equals("Junior")) {
            salario = 2500;
            resposta = "R$" + salario;
        } else if (cargo.equals("Pleno")) {
            salario = 4000;
            resposta = "R$" + salario;
        } else if (cargo.equals("Sênior")) {
            salario = 6000;
            resposta = "R$" + salario;
        }
        return resposta;
    }
    //Método que calcula a hora extra semanal
    public String calcHoraExtraSemana() {
        DecimalFormat mascara = new DecimalFormat("#,##0.00"); //máscara para que apenas dois números após a virgula apareca
        String resposta = "";
        float valorHoraExtra;
        if (cargo.equals("Aprendiz")) {
            valorHoraExtra = horasExtras * ((salario / 80) * 150 / 100);
            resposta = "R$" + mascara.format(valorHoraExtra);
        } else if (cargo.equals("Junior")) {
            valorHoraExtra = horasExtras * ((salario / 176) * 150 / 100);
            resposta = "R$" + mascara.format(valorHoraExtra);
        } else if (cargo.equals("Pleno")) {
            valorHoraExtra = horasExtras * ((salario / 176) * 150 / 100);
            resposta = "R$" + mascara.format(valorHoraExtra);
        } else if (cargo.equals("Sênior")) {
            valorHoraExtra = horasExtras * ((salario / 160) * 150 / 100);
            resposta = "R$" + mascara.format(valorHoraExtra);
        }
        return resposta;
    }
    //Método que calcula a hora extra aos domingos e feriados
    public String calcHoraExtraDomingoFeriado() {
        DecimalFormat mascara = new DecimalFormat("#,##0.00"); //máscara para que apenas dois números após a virgula apareca
        String resposta = "";
        float valorHoraExtra;
        if (cargo.equals("Aprendiz")) {
            valorHoraExtra = horasExtras * ((salario / 80) * 200 / 100);
            resposta = "R$" + mascara.format(valorHoraExtra);
        } else if (cargo.equals("Junior")) {
            valorHoraExtra = horasExtras * ((salario / 176) * 200 / 100);
            resposta = "R$" + mascara.format(valorHoraExtra);
        } else if (cargo.equals("Pleno")) {
            valorHoraExtra = horasExtras * ((salario / 176) * 200 / 100);
            resposta = "R$" + mascara.format(valorHoraExtra);
        } else if (cargo.equals("Sênior")) {
            valorHoraExtra = horasExtras * ((salario / 160) * 200 / 100);
            resposta = "R$" + mascara.format(valorHoraExtra);
        }
        return resposta;
    }

}
